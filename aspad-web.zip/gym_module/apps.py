from django.apps import AppConfig


class GymModuleConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "gym_module"
    verbose_name = "5. ماژول باشگاه ها"
