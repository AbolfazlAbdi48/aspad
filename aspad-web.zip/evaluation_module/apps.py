from django.apps import AppConfig


class EvaluationModuleConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "evaluation_module"
    verbose_name = "4. ماژول کارشناسی"
