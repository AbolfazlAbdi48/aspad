from django.apps import AppConfig


class AuctionModuleConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "auction_module"
    verbose_name = "3. ماژول مزایده"
